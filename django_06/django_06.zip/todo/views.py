from django.shortcuts import render, redirect
from .models import Todo
from datetime import datetime


def index(request):
    todos = Todo.objects.all().order_by("id")
    today = datetime.today().strftime("%Y-%m-%d")

    context = {
        "todos": todos,
        "today": today,
    }

    return render(request, "todo/index.html", context)


def create(request):
    # 1. parameter로 날라온 데이터를 받아서
    content = request.GET.get("content")
    # 우선순위 형변환해서 맞춤
    priority = int(request.GET.get("priority"))
    deadline = request.GET.get("deadline")

    # 2. DB에 저장
    Todo.objects.create(content=content, priority=priority, deadline=deadline)

    return redirect("todo:index")


def delete(request, pk):
    # pk에 해당하는 글 삭제
    Todo.objects.get(id=pk).delete()
    return redirect("todo:index")


def check(request, pk):
    # 1. pk에 해당하는 데이터의 completed
    todo = Todo.objects.get(id=pk)

    # 2. completed 여부(True/False) 수정
    if todo.completed == True:
        todo.completed = False
    else:
        todo.completed = True

    # 3. 수정된 데이터 저장
    todo.save()

    return redirect("todo:index")


def edit(request, pk):
    # 1. pk에 해당하는 데이터
    todo = Todo.objects.get(id=pk)
    # 날짜 포멧 맞춤
    deadline = todo.deadline.strftime("%Y-%m-%d")

    context = {
        "todo": todo,
    }

    return render(request, "todo:index", context)


def update(request, pk):
    # 1. pk에 해당하는 데이터
    todo = Todo.objects.get(id=pk)

    # 2. parameter로 날라온 데이터를 받아서
    content = request.GET.get("content")
    priority = int(request.GET.get("priority"))
    deadline = request.GET.get("deadline")

    # 3. 데이터 수정
    todo.content = content
    todo.priority = priority
    todo.deadline = deadline

    # 4. 수정된 데이터 저장
    todo.save()

    return redirect("todo:index")
