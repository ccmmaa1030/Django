from django.shortcuts import render
import random

# Create your views here.
def index(request):
    return render(request, "index.html")


def ping(request):
    return render(request, "ping.html")


def pong(request):
    # print(request)
    # print(dir(request))
    # print(request.GET.get('ball'))
    # name = request.GET.get('ball')
    # context = {
    #     'name': name,
    # }
    return render(request, "pong.html", {"name": request.GET.get("ball")})


def isoddeven(request, num):
    if num == 0:
        answer = "0"
    else:
        if num % 2 == 1:
            answer = "홀수"
        else:
            answer = "짝수"
    context = {
        "num": num,
        "answer": answer,
    }
    return render(request, "01_is_odd_even.html", context)


def caculate(request, num1, num2):
    context = {
        "num1": num1,
        "num2": num2,
        "answer1": num1 + num2,
        "answer2": num1 - num2,
        "answer3": num1 * num2,
        "answer4": num1 // num2,
    }
    return render(request, "02_caculate.html", context)


def pastlife(request):
    name = request.GET.get("name")
    context = {
        "name": name,
    }
    return render(request, "03_random.html", context)


def pastliferesult(request):
    hows = [
        "말 안듣는",
        "정신사나운",
        "귀여운",
        "느긋한",
        "외로운",
        "멍청한",
        "바보같은",
        "건강한",
        "인기 많은",
        "사랑스러운",
        "얌전한",
        "욕심많은",
        "천재",
        "깡패같은",
    ]
    whats = [
        "비글",
        "다람쥐",
        "토끼",
        "펭귄",
        "고양이",
        "앵무새",
        "상어",
        "비둘기",
        "햄스터",
        "오랑우탄",
        "침팬지",
        "라마",
        "미어캣",
        "바다사자",
        "가오리",
        "사막여우",
        "사자",
        "호랑이",
        "돼지",
        "곰",
        "스컹크",
    ]
    context = {
        "name": request.GET.get("name"),
        "how": random.choice(hows),
        "what": random.choice(whats),
    }
    return render(request, "03_random_result.html", context)


def lorem(request):
    paragraph = request.GET.get("paragraph")
    word = request.GET.get("word")
    context = {
        "paragraph": paragraph,
        "word": word,
    }
    return render(request, "04_lorem.html", context)


def loremresult(request):
    paragraph = request.GET.get("paragraph")
    word = request.GET.get("word")
    context = {
        "paragraph": paragraph,
        "word": word,
    }
    return render(request, "04_lorem_result.html", context)
