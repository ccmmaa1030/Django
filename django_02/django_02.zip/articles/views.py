from django.shortcuts import render
import random

# Create your views here.
# 1. 저녁 메뉴 추천
def menu(request):
    foods = ['초밥', '마라탕', '떡볶이', '라면', '카레']
    pictures = ['https://hajl.athuman.com/karuta/uploads/6e45128aad8bdcf39055b81840ecbe0186605633.jpeg',
            'https://mblogthumb-phinf.pstatic.net/MjAyMDAxMDZfNjAg/MDAxNTc4Mjk2Nzg4MDkz.ozpWU6UeQftpOFyy0-ntCFcgENUGNt29JOR7ahGiuCcg.XJcL8E_cauK0bOuuG92o4x6W47zW7fbMV0qRfWIpCSIg.JPEG.junef/%EB%A7%88%EB%9D%BC%ED%83%95.jpg?type=w800',
            'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/Tteokbokki.JPG/1200px-Tteokbokki.JPG',
            'https://i.ytimg.com/vi/mm2nZnDaxV8/maxresdefault.jpg',
            'https://recipe1.ezmember.co.kr/cache/recipe/2020/10/13/4bef6dd54a1395e9920a3489839317b51.jpg'
            ]
    food = random.choice(foods)
    pic = pictures[foods.index(food)]
    context = {
        'menu': food,
        'img': pic,
    }
    return render(request, 'menu.html', context)

# 2. 로또 번호 추첨
def lotto(request):
    context = {
        
    }
    return render(request, 'lotto.html', context)