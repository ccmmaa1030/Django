from django.shortcuts import render, redirect
from .models import Todo


def index(request):
    todos = Todo.objects.all().order_by("id")

    context = {
        "todos": todos,
    }

    return render(request, "todo/index.html", context)


def create(request):
    # 1. parameter로 날라온 데이터를 받아서
    content = request.GET.get("content")
    priority = int(request.GET.get("priority"))
    deadline = request.GET.get("deadline")

    # 2. DB에 저장
    Todo.objects.create(content=content, priority=priority, deadline=deadline)

    return redirect("todo:index")


def delete(request, pk):
    # pk에 해당하는 글 삭제
    Todo.objects.get(id=pk).delete()
    return redirect("todo:index")


def update(request, pk):
    # pk에 해당하는 글 수정
    return redirect("todo:index")
